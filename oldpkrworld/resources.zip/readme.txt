This is a texture pack made by Zombie1111 for my maps. You are allowed to use this in your own projects if you credit us!
Thanks for downloading and using our content :D